# 晴空纪元 EP001 · A版参考图

本包为4个30秒导演段，每段frames/恰好10张PNG。解压后打开reference-gallery.html浏览，按各段reference-order.md顺序使用。director-promt.txt已对应本段10张真实图。

角色基准可跨段复用；同一段没有重复内容凑数。使用内置imagegen生成/修正，无视频、音频或任务提交记录。API单任务时长和图片数量能力以后按实际平台确认。
